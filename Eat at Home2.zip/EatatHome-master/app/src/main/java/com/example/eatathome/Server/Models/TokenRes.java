package com.example.eatathome.Server.Models;

public class TokenRes {

    public String token;
    public boolean isServerToken;

    public TokenRes(){

    }

    public TokenRes(String token, boolean isServerToken) {
        this.token = token;
        this.isServerToken = isServerToken;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public boolean isServerToken() {
        return isServerToken;
    }

    public void setServerToken(boolean serverToken) {
        isServerToken = serverToken;
    }
}

