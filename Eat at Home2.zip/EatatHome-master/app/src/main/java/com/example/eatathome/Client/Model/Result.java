package com.example.eatathome.Client.Model;


class Result {

    public String message_id;
}
