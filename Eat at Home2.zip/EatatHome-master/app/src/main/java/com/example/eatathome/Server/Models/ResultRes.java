package com.example.eatathome.Server.Models;

public class ResultRes {
    public String message_id;
}
