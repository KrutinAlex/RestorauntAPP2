package com.example.eatathome.Administrator;

import com.example.eatathome.Administrator.Model.UserAdministrator;

public class ConstantAdmin {

    public static UserAdministrator currentUser;

    public static final String UPDATE = "Update";
    public static final String DELETE = "Delete";

    public static final int PICK_IMAGE_REQUEST = 71;
}
